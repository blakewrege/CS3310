package edu.wmich.cs3310.a2;

/********************************
 * Countries Of The World App 1.0
 * DataTable node
 * @author Caleb Viola
 */
public class BSTNode {
	String name;
	short drp;
	short leftChPtr, rightChPtr;
}
